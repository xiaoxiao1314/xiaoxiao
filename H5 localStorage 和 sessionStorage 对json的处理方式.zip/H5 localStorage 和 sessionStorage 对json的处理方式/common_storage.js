
	//session缓存  键值对
	this.setObject = function (key, obj)
    {
        var str = null;
        if (obj != null && obj != undefined)
        {
            str = JSON.stringify(obj);
        }
        sessionStorage.setItem(key, str);
    }
    //移除指定的session存储
    this.remove = function (key)
    {
        sessionStorage.removeItem(key);
    };
    //获取session存储的对象
    this.getObject = function (key)
    {
        var str = sessionStorage.getItem(key);
        if (str == undefined || str == null || str.length == 0) return null;

        try
        {
            var obj = eval('(' + str + ')');
            return obj;
        }
        catch (e)
        {
            return null;
        }
    };
    //向session中添加数据
    //key自定义名称  ID动态生成   自定义json
    this.wapcarinfoadd = function(key,id,json){
    	var listCarinfo = getObject(key);
    	var obj = {};
    	if(listCarinfo != null && listCarinfo != ""){	//判断是不是第一次添加数据
    		listCarinfo[id] = json;
    		setObject(key,listCarinfo);	
    	}else{
    		obj[id] = json;
    		setObject(key,obj);
    	}
    };
    //删除session的数据中指定数据
    //key查询自定义名称  ID动态生成删除
    this.wapcarinfodel = function(key,id){
    	var listCarinfo = getObject(key);
		carjson = JSON.parse(JSON.stringify(listCarinfo));
		delete carjson[id];
	 	remove(key);
	 	setObject(key,carjson);
    };
    
    
