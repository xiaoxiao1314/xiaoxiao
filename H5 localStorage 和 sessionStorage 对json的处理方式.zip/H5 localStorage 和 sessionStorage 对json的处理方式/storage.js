function clikes(){
	for (i=0;i<10;i++) {
		var carinfoid = "carinfo"+i;
    	var jsons = {carinfoid:i};
		wapcarinfoadd("carinfo_list",carinfoid,jsons);
	}
}
function jiexie(){
	var listCarinfo = getObject("carinfo_list");
	var num = 0;
	var html = "";
	for(var a in listCarinfo){
        num++;
       	html += "<div>id++++++++++++++++++++++++ "+listCarinfo[a].carinfoid+"<button onclick=\"yichu(\'"+a+"\')\">移除</button></div>";
    }
	$(".sss").html(html);
}

function yichu(id){
	wapcarinfodel("carinfo_list",id);
	jiexie();
}
